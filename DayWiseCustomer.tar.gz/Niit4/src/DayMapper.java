import java.io.IOException;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DayMapper extends Mapper<LongWritable, Text, Text, FloatWritable>
{
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		try {
			String[] rec = value.toString().split(";");
			
			String[] mydate = rec[0].trim().split("-");
			
			String dt = mydate[2];
			
		    
			String custid= rec[1].trim();
	        float sales = Float.parseFloat(rec[8]);
			String myValue = dt + ',' + custid;
			context.write(new Text(myValue), new FloatWritable(sales));			
		} catch (IndexOutOfBoundsException e) {
		} catch (ArithmeticException e1) {
		}
	}	
}